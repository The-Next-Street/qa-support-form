import React, { useState, useEffect, useMemo } from "react";
import { COLORS, FONTS, GRADIENT } from "../brand";
import { headerStyles } from "./ui";
import {
  qaFetch, listEvaluatorPairs, listAssignments, saveAssignments,
  setAssignmentStatus, deleteAssignment as apiDeleteAssignment,
} from "../qaApi";

// ── Styles ──────────────────────────────────────────────────────────────────

const s = {
  page: { minHeight: "100vh", background: COLORS.offWhite, padding: "24px 16px", fontFamily: FONTS.body },
  card: { maxWidth: 1100, margin: "0 auto", background: COLORS.white, borderRadius: 12, border: "1px solid #E8E8E8", boxShadow: "0 1px 3px rgba(0,0,0,0.04)", overflow: "hidden" },
  ...headerStyles,
  body: { padding: "28px 32px" },

  topBar: { display: "flex", gap: 16, marginBottom: 24, alignItems: "center", flexWrap: "wrap" },
  generateBtn: (disabled) => ({
    padding: "10px 24px",
    background: disabled ? "#aaa" : GRADIENT.orange,
    color: COLORS.white,
    border: "none",
    borderRadius: 8,
    fontSize: 14,
    fontWeight: 700,
    fontFamily: FONTS.heading,
    cursor: disabled ? "not-allowed" : "pointer",
  }),
  dateInput: {
    padding: "8px 12px",
    borderRadius: 8,
    border: `1.5px solid ${COLORS.lightGray}`,
    fontSize: 14,
    fontFamily: FONTS.body,
  },
  label: { fontSize: 13, fontWeight: 600, color: COLORS.gray, marginBottom: 4 },

  statsRow: { display: "flex", gap: 16, marginBottom: 24, flexWrap: "wrap" },
  statCard: (color) => ({
    flex: "1 1 140px",
    padding: "16px",
    borderRadius: 10,
    background: COLORS.white,
    border: `2px solid ${color}`,
    textAlign: "center",
  }),
  statNum: (color) => ({ fontSize: 28, fontWeight: 800, fontFamily: FONTS.heading, color, margin: 0 }),
  statLabel: { fontSize: 11, color: COLORS.midGray, marginTop: 4, textTransform: "uppercase", letterSpacing: 0.5, fontWeight: 600 },

  // Evaluator section
  evalSection: { marginBottom: 24, border: `1px solid ${COLORS.lightGray}`, borderRadius: 10, overflow: "hidden" },
  evalHeader: {
    padding: "12px 16px",
    background: COLORS.charcoal,
    color: COLORS.white,
    fontFamily: FONTS.heading,
    fontWeight: 700,
    fontSize: 15,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    cursor: "pointer",
  },
  agentGroup: { padding: "16px", borderBottom: `1px solid ${COLORS.lightGray}` },
  agentName: { fontWeight: 700, color: COLORS.gray, fontSize: 15, fontFamily: FONTS.heading, marginBottom: 8 },

  // Interaction table
  table: { width: "100%", borderCollapse: "collapse", fontSize: 13 },
  th: { textAlign: "left", padding: "6px 10px", background: "#F5F5F5", fontWeight: 600, fontSize: 11, textTransform: "uppercase", color: COLORS.midGray },
  td: { padding: "8px 10px", borderBottom: `1px solid ${COLORS.offWhite}`, color: COLORS.gray },
  contactId: { fontFamily: "monospace", fontSize: 13, fontWeight: 600, color: COLORS.sky },
  channelPill: (ch) => ({
    display: "inline-block",
    padding: "2px 8px",
    borderRadius: 8,
    fontSize: 11,
    fontWeight: 600,
    background: "#FEF3E2",
    color: COLORS.orange,
  }),
  statusCheck: { width: 18, height: 18, cursor: "pointer", accentColor: COLORS.green },
  screenBtn: {
    padding: "4px 12px",
    background: COLORS.orange,
    color: COLORS.white,
    border: "none",
    borderRadius: 6,
    fontSize: 12,
    fontWeight: 600,
    fontFamily: FONTS.heading,
    cursor: "pointer",
  },

  center: { textAlign: "center", padding: "48px 20px", color: COLORS.midGray, fontSize: 15 },
  errorBox: { background: COLORS.failBg, border: "1px solid #FFCDD2", borderRadius: 8, padding: "12px 16px", color: COLORS.fail, fontSize: 14, marginBottom: 16 },
  warningBox: { background: COLORS.warningBg, border: `1px solid ${COLORS.clementine}`, borderRadius: 8, padding: "12px 16px", fontSize: 13, color: "#795548", marginBottom: 16 },
};

// ── Helpers: QA service ─────────────────────────────────────────────────────

// Evaluator → agent pairings (managed on the Settings page).
async function fetchEvaluatorAgents() {
  const data = await listEvaluatorPairs();
  return (data.pairs || []).map((p) => ({
    evaluatorName: p.evaluator_name,
    evaluatorEmail: p.evaluator_email,
    agentName: p.agent_name,
    agentCxoneId: p.cxone_agent_id,
  }));
}

// Saved assignments, in the field shape this screen was built around.
async function fetchAssignments() {
  const data = await listAssignments();
  return (data.assignments || []).map((x) => ({
    id: x.id,
    Evaluator: x.evaluator_name,
    Agent: x.agent_name,
    ContactId: x.contact_id,
    Channel: x.channel,
    InteractionDate: x.interaction_date,
    Duration: x.duration_seconds,
    SkillName: x.skill_name,
    WeekOf: x.week_of,
    Status: x.status,
    screening: x.screening_id
      ? { scorePercent: x.score_percent, passFail: x.pass_fail }
      : null,
  }));
}

// ── Helper: get Monday of the week ─────────────────────────────────────────

function getMonday(date = new Date()) {
  const d = new Date(date);
  const day = d.getDay();
  d.setDate(d.getDate() - (day === 0 ? 6 : day - 1));
  return d.toISOString().split("T")[0];
}

function getNextMonday() {
  const d = new Date();
  d.setDate(d.getDate() + (8 - d.getDay()) % 7);
  return d.toISOString().split("T")[0];
}

// ── Component ───────────────────────────────────────────────────────────────

export default function Assignments({ onScreen, refreshKey = 0 }) {
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [genErrors, setGenErrors] = useState([]);
  const [dueDate, setDueDate] = useState(getNextMonday());
  const [weekOf, setWeekOf] = useState(getMonday());
  const [expandedEvals, setExpandedEvals] = useState({});
  // "pending" (default) shows only un-screened assignments; "completed" shows the rest
  const [view, setView] = useState("pending");

  // Load assignments for current week
  useEffect(() => {
    async function load() {
      setLoading(true);
      setError(null);
      try {
        setAssignments(await fetchAssignments());
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [weekOf, refreshKey]);

  // Generate assignments
  async function handleGenerate() {
    setGenerating(true);
    setError(null);
    setGenErrors([]);

    try {
      // 1. Evaluator → agent pairings
      const config = await fetchEvaluatorAgents();
      if (config.length === 0) {
        setError("No evaluator pairings yet. A manager can add them on the Settings page.");
        setGenerating(false);
        return;
      }

      // 2. Call backend to generate from CXone
      const res = await qaFetch("/api/assignments/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          evaluator_agents: config.map((c) => ({
            evaluatorName: c.evaluatorName,
            evaluatorEmail: c.evaluatorEmail,
            agentName: c.agentName,
            agentCxoneId: c.agentCxoneId,
          })),
          screening_due_date: dueDate,
          interactions_per_agent: 3,
        }),
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Backend error ${res.status}: ${text}`);
      }

      const result = await res.json();
      if (result.errors?.length) setGenErrors(result.errors);

      // 3. Save the picked interactions
      const newWeekOf = result.weekOf;
      const rows = [];
      for (const assignment of result.assignments) {
        for (const interaction of assignment.interactions) {
          rows.push({
            evaluatorName: assignment.evaluatorName || "",
            evaluatorEmail: assignment.evaluatorEmail || "",
            agentName: assignment.agentName || "",
            agentCxoneId: assignment.agentCxoneId || null,
            contactId: String(interaction.contactId || ""),
            channel: interaction.channel || "Phone",
            interactionDate: interaction.interactionDate || null,
            duration: Math.round(Number(interaction.duration) || 0),
            skillName: interaction.skillName || "",
          });
        }
      }
      if (rows.length > 0) await saveAssignments({ weekOf: newWeekOf, assignments: rows });

      // 4. Refresh the list
      setWeekOf(newWeekOf);
      setAssignments(await fetchAssignments());
    } catch (err) {
      setError(err.message);
    } finally {
      setGenerating(false);
    }
  }

  // Toggle status
  async function toggleStatus(item) {
    const newStatus = item.Status === "Completed" ? "Pending" : "Completed";
    try {
      await setAssignmentStatus(item.id, newStatus);
      setAssignments((prev) =>
        prev.map((a) => (a.id === item.id ? { ...a, Status: newStatus } : a))
      );
    } catch (err) {
      console.warn("Failed to update status:", err);
    }
  }

  async function deleteAssignment(item) {
    const confirmed = window.confirm(
      `Delete this assignment for ${item.Agent || "unknown agent"}?\n\nContact ID: ${item.ContactId || "-"}\n\nThis cannot be undone.`
    );
    if (!confirmed) return;
    try {
      await apiDeleteAssignment(item.id);
      setAssignments((prev) => prev.filter((a) => a.id !== item.id));
    } catch (err) {
      setError(`Could not delete: ${err.message}`);
    }
  }

  // Filter assignments by current view (Pending vs Completed)
  const visibleAssignments = useMemo(() => {
    return assignments.filter((a) => {
      const isCompleted = a.Status === "Completed";
      return view === "completed" ? isCompleted : !isCompleted;
    });
  }, [assignments, view]);

  // Group visible assignments by evaluator then agent
  const grouped = useMemo(() => {
    const map = {};
    visibleAssignments.forEach((a) => {
      const key = a.Evaluator || "Unassigned";
      if (!map[key]) map[key] = {};
      const agentKey = a.Agent || "Unknown";
      if (!map[key][agentKey]) map[key][agentKey] = [];
      map[key][agentKey].push(a);
    });
    return map;
  }, [visibleAssignments]);

  const evaluators = Object.keys(grouped).sort();

  // Stats
  const stats = useMemo(() => {
    const total = assignments.length;
    const completed = assignments.filter((a) => a.Status === "Completed").length;
    const agents = new Set(assignments.map((a) => a.Agent)).size;
    return { total, completed, pending: total - completed, agents };
  }, [assignments]);

  function toggleEval(name) {
    setExpandedEvals((prev) => ({ ...prev, [name]: !prev[name] }));
  }

  function formatDuration(sec) {
    if (!sec) return "-";
    const m = Math.floor(sec / 60);
    const sLeft = sec % 60;
    return `${m}m ${String(sLeft).padStart(2, "0")}s`;
  }

  function formatDate(dateStr) {
    if (!dateStr) return "-";
    try {
      return new Date(dateStr).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    } catch { return dateStr; }
  }

  return (
    <div style={s.page}>
      <div style={s.card}>
        <div style={s.header}>
          <h1 style={s.headerTitle}>QA Assignments</h1>
          <p style={s.headerSub}>Weekly interaction assignments for quality screening</p>
        </div>

        <div style={s.body}>
          {/* Top controls */}
          <div style={s.topBar}>
            <div>
              <div style={s.label}>Screening Due Date</div>
              <input
                type="date"
                style={s.dateInput}
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
            <div>
              <div style={s.label}>Viewing Week Of</div>
              <input
                type="date"
                style={s.dateInput}
                value={weekOf}
                onChange={(e) => setWeekOf(e.target.value)}
              />
            </div>
            <div style={{ marginTop: 18 }}>
              <button
                style={s.generateBtn(generating)}
                onClick={handleGenerate}
                disabled={generating}
              >
                {generating ? "Generating..." : "Generate This Week's Assignments"}
              </button>
            </div>
          </div>

          {/* Pending / Completed toggle */}
          {assignments.length > 0 && (
            <div style={{
              display: "inline-flex",
              borderRadius: 8,
              border: `1.5px solid ${COLORS.lightGray}`,
              overflow: "hidden",
              marginBottom: 16,
            }}>
              {[
                { key: "pending", label: `Pending (${stats.pending})` },
                { key: "completed", label: `Completed (${stats.completed})` },
              ].map((tab) => {
                const active = view === tab.key;
                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => setView(tab.key)}
                    style={{
                      padding: "8px 18px",
                      fontFamily: FONTS.heading,
                      fontSize: 13,
                      fontWeight: 700,
                      border: "none",
                      cursor: "pointer",
                      background: active ? GRADIENT.orange : COLORS.white,
                      color: active ? COLORS.white : COLORS.gray,
                    }}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>
          )}

          {/* Errors / warnings */}
          {error && <div style={s.errorBox}>{"\u26A0"} {error}</div>}
          {genErrors.length > 0 && (
            <div style={s.warningBox}>
              <strong>Warnings:</strong>
              <ul style={{ margin: "8px 0 0", paddingLeft: 20 }}>
                {genErrors.map((e, i) => <li key={i}>{e}</li>)}
              </ul>
            </div>
          )}

          {loading ? (
            <div style={s.center}>
              <p>Loading assignments...</p>
              <style>{`@keyframes pulse { 0%,100% { opacity:.3 } 50% { opacity:1 } }`}</style>
            </div>
          ) : assignments.length === 0 ? (
            <div style={s.center}>
              <p style={{ fontSize: 18, fontFamily: FONTS.heading, color: COLORS.gray }}>
                No assignments for this week
              </p>
              <p>Click "Generate This Week's Assignments" to create them from CXone data.</p>
            </div>
          ) : visibleAssignments.length === 0 ? (
            <div style={s.center}>
              <p style={{ fontSize: 18, fontFamily: FONTS.heading, color: COLORS.gray }}>
                {view === "completed" ? "No completed screenings yet" : "All screenings complete 🎉"}
              </p>
              <p>
                {view === "completed"
                  ? "Complete a screening from Pending to see it here."
                  : "Nice work — nothing left to screen."}
              </p>
            </div>
          ) : (
            <>
              {/* Stats */}
              <div style={s.statsRow}>
                <div style={s.statCard(COLORS.orange)}>
                  <p style={s.statNum(COLORS.orange)}>{stats.total}</p>
                  <p style={s.statLabel}>Total</p>
                </div>
                <div style={s.statCard(COLORS.green)}>
                  <p style={s.statNum(COLORS.green)}>{stats.completed}</p>
                  <p style={s.statLabel}>Completed</p>
                </div>
                <div style={s.statCard(COLORS.sky)}>
                  <p style={s.statNum(COLORS.sky)}>{stats.pending}</p>
                  <p style={s.statLabel}>Pending</p>
                </div>
                <div style={s.statCard(COLORS.gray)}>
                  <p style={s.statNum(COLORS.gray)}>{stats.agents}</p>
                  <p style={s.statLabel}>Agents</p>
                </div>
              </div>

              {/* Assignments by evaluator */}
              {evaluators.map((evalName) => {
                const agents = grouped[evalName];
                const agentNames = Object.keys(agents).sort();
                const isOpen = expandedEvals[evalName] !== false; // Default open
                const evalTotal = agentNames.reduce((sum, a) => sum + agents[a].length, 0);
                const evalDone = agentNames.reduce(
                  (sum, a) => sum + agents[a].filter((x) => x.Status === "Completed").length, 0
                );

                return (
                  <div key={evalName} style={s.evalSection}>
                    <div style={s.evalHeader} onClick={() => toggleEval(evalName)}>
                      <span>{isOpen ? "\u25BC" : "\u25B6"} {evalName}</span>
                      <span style={{ fontSize: 12, fontWeight: 400, color: "rgba(255,255,255,0.7)" }}>
                        {evalDone}/{evalTotal} completed
                      </span>
                    </div>
                    {isOpen && agentNames.map((agentName) => (
                      <div key={agentName} style={s.agentGroup}>
                        <div style={s.agentName}>{agentName}</div>
                        <table style={s.table}>
                          <thead>
                            <tr>
                              <th style={s.th}>Contact ID</th>
                              <th style={s.th}>Channel</th>
                              <th style={s.th}>Date</th>
                              <th style={s.th}>Duration</th>
                              <th style={s.th}>Skill</th>
                              {view === "completed" && (
                                <>
                                  <th style={{ ...s.th, textAlign: "right" }}>Score</th>
                                  <th style={{ ...s.th, textAlign: "right" }}>Result</th>
                                </>
                              )}
                              <th style={{ ...s.th, textAlign: "center" }}>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {agents[agentName].map((item) => {
                              const screening = item.screening;
                              return (
                              <tr key={item.id}>
                                <td style={{ ...s.td, ...s.contactId }}>{item.ContactId}</td>
                                <td style={s.td}><span style={s.channelPill(item.Channel)}>{item.Channel}</span></td>
                                <td style={s.td}>{formatDate(item.InteractionDate)}</td>
                                <td style={s.td}>{formatDuration(item.Duration)}</td>
                                <td style={s.td}>{item.SkillName || "-"}</td>
                                {view === "completed" && (
                                  <>
                                    <td style={{
                                      ...s.td, textAlign: "right", fontWeight: 700,
                                      color: !screening ? COLORS.midGray
                                        : screening.scorePercent >= 80 ? COLORS.green
                                        : screening.scorePercent < 60 ? COLORS.fail
                                        : COLORS.orange,
                                    }}>
                                      {screening ? `${screening.scorePercent}%` : "—"}
                                    </td>
                                    <td style={{
                                      ...s.td, textAlign: "right", fontWeight: 600,
                                      color: !screening ? COLORS.midGray
                                        : screening.passFail === "Pass" ? COLORS.green : COLORS.fail,
                                    }}>
                                      {screening?.passFail || "—"}
                                    </td>
                                  </>
                                )}
                                <td style={{ ...s.td, textAlign: "center" }}>
                                  {item.Status === "Completed" ? (
                                    <button
                                      type="button"
                                      style={{
                                        ...s.screenBtn,
                                        background: COLORS.white,
                                        color: COLORS.gray,
                                        border: `1.5px solid ${COLORS.lightGray}`,
                                      }}
                                      onClick={() => toggleStatus(item)}
                                      title="Re-open this assignment (move back to Pending)"
                                    >
                                      Re-open
                                    </button>
                                  ) : (
                                    <button
                                      type="button"
                                      style={s.screenBtn}
                                      onClick={() =>
                                        onScreen && onScreen({
                                          assignmentId: item.id,
                                          agentName: item.Agent || agentName,
                                          channel: item.Channel,
                                          contactId: item.ContactId,
                                          skillName: item.SkillName,
                                          interactionDate: item.InteractionDate,
                                        })
                                      }
                                    >
                                      Screen
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() => deleteAssignment(item)}
                                    title="Delete this assignment"
                                    style={{
                                      marginLeft: 8,
                                      padding: "6px 8px",
                                      background: "transparent",
                                      border: "none",
                                      cursor: "pointer",
                                      color: COLORS.midGray,
                                      fontSize: 14,
                                      lineHeight: 1,
                                    }}
                                    onMouseEnter={(e) => (e.currentTarget.style.color = COLORS.fail)}
                                    onMouseLeave={(e) => (e.currentTarget.style.color = COLORS.midGray)}
                                  >
                                    🗑
                                  </button>
                                </td>
                              </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    ))}
                  </div>
                );
              })}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
